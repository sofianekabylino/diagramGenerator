function init() {
    var $ = go.GraphObject.make;
    myDiagram =
$(go.Diagram, 'myDiagram',  // must name or refer to the DIV HTML element
{
initialAutoScale: go.Diagram.Uniform,  // an initial automatic zoom-to-fit
contentAlignment: go.Spot.Center,  // align document to the center of the viewport
layout:
$(go.ForceDirectedLayout,  // automatically spread nodes apart
{ defaultSpringLength: 30, defaultElectricalCharge: 100 })
});
// define each Node's appearance
myDiagram.nodeTemplate =
$(go.Node, 'Auto',  // the whole node panel
// define the node's outer shape, which will surround the TextBlock
$(go.Shape, 'Rectangle',
{ fill: $(go.Brush, 'Linear', { 0: 'rgb(254, 201, 0)', 1: 'rgb(254, 162, 0)' }), stroke: 'black' }),
$(go.TextBlock,
{ font: 'bold 10pt helvetica, bold arial, sans-serif', margin: 4 },
new go.Binding('text', 'text'))
);
    // show visibility or access as a single character at the beginning of each property or method
    function convertVisibility(v) {
      switch (v) {
        case 'public': return '+';
        case 'private': return '-';
        case 'protected': return '#';
        case 'package': return '~';
        default: return v;
      }
    }
    // the item template for properties
    var propertyTemplate =
      $(go.Panel, 'Horizontal',
        // property visibility/access
        $(go.TextBlock,
{ isMultiline: false, editable: false, width: 12 },
new go.Binding('text', 'visibility', convertVisibility)),
// property name, underlined if scope=='class' to indicate static property
$(go.TextBlock,
{ isMultiline: false, editable: true },
new go.Binding('text', 'name').makeTwoWay(),
new go.Binding('isUnderline', 'scope', function(s) { return s[0] === 'c' })),
// property type, if known
$(go.TextBlock, '',
new go.Binding('text', 'type', function(t) { return (t ? ': ' : ''); })),
$(go.TextBlock,
{ isMultiline: false, editable: true },
new go.Binding('text', 'type').makeTwoWay()),
// property default value, if any
$(go.TextBlock,
{ isMultiline: false, editable: false },
new go.Binding('text', 'default', function(s) { return s ? ' = ' + s : ''; }))
);
// the item template for methods
var methodTemplate =
$(go.Panel, 'Horizontal',
// method visibility/access
$(go.TextBlock,
{ isMultiline: false, editable: false, width: 12 },
new go.Binding('text', 'visibility', convertVisibility)),
// method name, underlined if scope=='class' to indicate static method
$(go.TextBlock,
{ isMultiline: false, editable: true },
new go.Binding('text', 'name').makeTwoWay(),
new go.Binding('isUnderline', 'scope', function(s) { return s[0] === 'c' })),
// method parameters
$(go.TextBlock, '()',
// this does not permit adding/editing/removing of parameters via inplace edits
new go.Binding('text', 'parameters', function(parr) {
var s = '(';
for (var i = 0; i < parr.length; i++) {
var param = parr[i];
if (i > 0) s += ', ';
s += param.name + ': ' + param.type;
}
return s + ')';
})),
// method return type, if any
$(go.TextBlock, '',
new go.Binding('text', 'type', function(t) { return (t ? ': ' : ''); })),
$(go.TextBlock,
{ isMultiline: false, editable: true },
new go.Binding('text', 'type').makeTwoWay())
);
// this simple template does not have any buttons to permit adding or
// removing properties or methods, but it could!
myDiagram.nodeTemplate =
$(go.Node, 'Auto',
{
locationSpot: go.Spot.Center,
fromSpot: go.Spot.AllSides,
toSpot: go.Spot.AllSides
},
$(go.Shape, { fill: 'lightyellow' }),
$(go.Panel, 'Table',
{ defaultRowSeparatorStroke: 'black' },
// header
$(go.TextBlock,
{
row: 0, margin: 3, alignment: go.Spot.Center,
font: 'bold 12pt sans-serif',
isMultiline: false, editable: true
},
new go.Binding('text', 'name').makeTwoWay()),
// properties
$(go.Panel, 'Vertical',
new go.Binding('itemArray', 'properties'),
{
row: 1, margin: 3, alignment: go.Spot.Left,
defaultAlignment: go.Spot.Left,
itemTemplate: propertyTemplate
}
),
// methods
$(go.Panel, 'Vertical',
new go.Binding('itemArray', 'methods'),
{
row: 2, margin: 3, alignment: go.Spot.Left,
defaultAlignment: go.Spot.Left,
itemTemplate: methodTemplate
}
))
);
function convertIsTreeLink(r) {
return r === 'generalization';
}
function convertFromArrow(r) {
switch (r) {
case 'generalization': return '';
default: return '';
}
}
function convertToArrow(r) {
switch (r) {
case 'generalization': return 'Triangle';
//case 'aggregation': return 'StretchedDiamond';
case 'aggregation': return 'OpenTriangle';
case 'association': return 'OpenTriangle';
case 'implements': return 'OpenTriangle';
default: return '';
}
}
function convertLink(r){
switch (r) {
case 'implements' : return [5,10];
}
}
myDiagram.linkTemplate =
$(go.Link,
{ routing: go.Link.AvoidsNodes },
new go.Binding('isLayoutPositioned', 'relationship', convertIsTreeLink),
$(go.Shape,{stroke:'black'},
new go.Binding('strokeDashArray' , 'relationship', convertLink)),
$(go.Shape, { scale: 1.3, fill: 'white' },
new go.Binding('fromArrow', 'relationship', convertFromArrow)),
$(go.Shape, { scale: 1.3, fill: 'white' },
new go.Binding('toArrow', 'relationship', convertToArrow)),
$(go.TextBlock,
{ segmentIndex: -1, segmentOffset: new go.Point(NaN, NaN),
segmentOrientation: go.Link.OrientUpright },
new go.Binding('text', 'text'))

);
// setup a few example class nodes and relationships
var nodedata = [{"methods":[],"name":"DirectionEnum","key":1,"properties":[{"name":"NORTH"},{"name":"NORTH_EAST"},{"name":"EAST"},{"name":"SOUTH_EAST"},{"name":"SOUTH"},{"name":"SOUTH_WEST"},{"name":"WEST"},{"name":"NORTH_WEST"},{"name":"NONE"}]},{"methods":[],"name":"TypeOfAgentEnum","key":2,"properties":[{"name":"BILLE"},{"name":"FISH"},{"name":"SHARK"},{"name":"CHASED"},{"name":"HUNTER"},{"name":"EMPTY"},{"name":"WALL"}]},{"methods":[{"visibility":"public","name":"getEnvironnement","type":"MultiAgentsParticules.core.Environnement"},{"visibility":"public","name":"generateInitDirection","type":"MultiAgentsParticules.core.enums.DirectionEnum"},{"visibility":"public","name":"getType","type":"MultiAgentsParticules.core.enums.TypeOfAgentEnum"},{"visibility":"public","name":"isTaken","type":"boolean"},{"visibility":"public","name":"getB","type":"int"},{"visibility":"public","name":"getG","type":"int"},{"visibility":"public","name":"getId","type":"int"},{"visibility":"public","name":"getPositionX","type":"int"},{"visibility":"public","name":"getPositionY","type":"int"},{"visibility":"public","name":"getR","type":"int"},{"visibility":"public","name":"getColor","type":"java.awt.Color"},{"visibility":"public","name":"toString","type":"java.lang.String"},{"visibility":"public","name":"deplacement","type":"void"},{"visibility":"public","name":"doIt","type":"void"},{"visibility":"public","name":"setColor","type":"void"},{"visibility":"public","name":"setDirection","type":"void"},{"visibility":"public","name":"setEnvironnement","type":"void"},{"visibility":"public","name":"setId","type":"void"},{"visibility":"public","name":"setNbCycleReproduction","type":"void"},{"visibility":"public","name":"setPositionX","type":"void"},{"visibility":"public","name":"setPositionY","type":"void"},{"visibility":"private","name":"setRoundForSpeak","type":"void"},{"visibility":"public","name":"setType","type":"void"}],"name":"Agent","key":3,"properties":[{"visibility":"protected","name":"id","type":"int"},{"visibility":"protected","name":"positionX","type":"int"},{"visibility":"protected","name":"positionY","type":"int"},{"visibility":"protected","name":"couleur","type":"java.awt.Color"},{"visibility":"protected","name":"r","type":"int"},{"visibility":"protected","name":"g","type":"int"},{"visibility":"protected","name":"b","type":"int"},{"visibility":"protected","name":"initialisation","type":"boolean"},{"visibility":"protected","name":"color","type":"java.awt.Color"},{"visibility":"protected","name":"nbCycleReproduction","type":"int"},{"visibility":"protected","name":"roundForSpeak","type":"int"}]},{"methods":[{"visibility":"public","name":"getEspace","type":"MultiAgentsParticules.core.Agent[][]"},{"visibility":"public","name":"getHeight","type":"int"},{"visibility":"public","name":"getWidth","type":"int"},{"visibility":"public","name":"getMatriceDijkstra","type":"int[][]"},{"visibility":"public","name":"getNeighbors","type":"java.util.List<MultiAgentsParticules.core.Agent>"},{"visibility":"public","name":"init","type":"void"},{"visibility":"public","name":"initDijsktra","type":"void"},{"visibility":"public","name":"initMatrice","type":"void"},{"visibility":"public","name":"setHeight","type":"void"},{"visibility":"public","name":"setWidth","type":"void"},{"visibility":"public","name":"updateMatrice","type":"void"}],"name":"Environnement","key":4,"properties":[{"visibility":"private","name":"espace","type":"MultiAgentsParticules.core.Agent[][]"},{"visibility":"private","name":"height","type":"int"},{"visibility":"private","name":"width","type":"int"},{"visibility":"public","name":"matriceDijkstra","type":"int[][]"}]},{"methods":[{"visibility":"public","name":"getEnvironnement","type":"MultiAgentsParticules.core.Environnement"},{"visibility":"public","name":"getCurrentTurn","type":"int"},{"visibility":"public","name":"getNbFish","type":"int"},{"visibility":"public","name":"getNbShark","type":"int"},{"visibility":"public","name":"getAgents","type":"java.util.List<MultiAgentsParticules.core.Agent>"},{"visibility":"public","name":"initBille","type":"void"},{"visibility":"public","name":"initFishShark","type":"void"},{"visibility":"public","name":"initPursuit","type":"void"},{"visibility":"public","name":"nbTypeOfAgent","type":"void"},{"visibility":"public","name":"run","type":"void"},{"visibility":"public","name":"runJFX","type":"void"},{"visibility":"public","name":"setNbFish","type":"void"},{"visibility":"public","name":"setNbShark","type":"void"}],"name":"SMA","key":5,"properties":[{"visibility":"private","name":"view","type":"MultiAgentsParticules.wator.view.View"},{"visibility":"private","name":"mCurrentTurn","type":"int"},{"visibility":"private","name":"cptFish","type":"int"},{"visibility":"private","name":"cptShark","type":"int"}]},{"methods":[{"visibility":"public","name":"doIt","type":"void"}],"name":"Empty","key":6,"properties":[]},{"methods":[],"name":"GameOverExcception","key":7,"properties":[]},{"methods":[{"visibility":"public","name":"doIt","type":"void"}],"name":"Hunted","key":8,"properties":[{"visibility":"private","name":"initialisation","type":"boolean"},{"visibility":"private","name":"cmptRoundForSpeak","type":"int"}]},{"methods":[{"visibility":"public","name":"doIt","type":"void"}],"name":"Hunter","key":9,"properties":[{"visibility":"private","name":"cmptRoundForSpeak","type":"int"}]},{"methods":[{"visibility":"public","name":"doIt","type":"void"}],"name":"Wall","key":10,"properties":[]},{"methods":[{"visibility":"public","name":"clean","type":"void"},{"visibility":"public","name":"fillCell","type":"void"},{"visibility":"protected","name":"paintComponent","type":"void"},{"visibility":"public","name":"repaint","type":"void"}],"name":"Grid","key":11,"properties":[{"visibility":"private","name":"fillCells","type":"java.util.List<java.awt.Point>"},{"visibility":"private","name":"width","type":"int"},{"visibility":"private","name":"height","type":"int"},{"visibility":"private","name":"mapColors","type":"java.util.Map<java.awt.Point, java.awt.Color>"},{"visibility":"private","name":"mapValue","type":"java.util.Map<java.awt.Point, java.lang.Integer>"}]},{"methods":[{"visibility":"public","name":"keyPressed","type":"void"},{"visibility":"public","name":"keyReleased","type":"void"},{"visibility":"public","name":"keyTyped","type":"void"},{"visibility":"public","name":"launch","type":"void"},{"visibility":"public","name":"update","type":"void"}],"name":"ViewPursuit","key":12,"properties":[{"visibility":"private","name":"frame","type":"javax.swing.JFrame"},{"visibility":"private","name":"matrice","type":"int[][]"},{"visibility":"private","name":"torique","type":"boolean"},{"visibility":"private","name":"speed","type":"int"},{"visibility":"private","name":"sizeAgent","type":"int"}]},{"methods":[{"visibility":"public","name":"getSma","type":"MultiAgentsParticules.core.SMA"},{"visibility":"public","name":"main","type":"void"},{"visibility":"public","name":"setSma","type":"void"}],"name":"Main","key":13,"properties":[]}] 
;
var linkdata = [{"from":3,"to":1,"text":"direction","relationship":"association"},{"from":3,"to":4,"text":"environnement","relationship":"association"},{"from":3,"to":2,"text":"type","relationship":"association"},{"from":5,"to":4,"text":"environnement","relationship":"association"},{"from":5,"to":3,"text":"1..*","relationship":"aggregation"},{"from":6,"to":3,"relationship":"generalization"},{"from":8,"to":3,"relationship":"generalization"},{"from":9,"to":3,"relationship":"generalization"},{"from":10,"to":3,"relationship":"generalization"},{"from":12,"to":5,"text":"sma","relationship":"association"},{"from":12,"to":11,"text":"grid","relationship":"association"},{"from":12,"to":3,"text":"agentChased","relationship":"association"},{"from":13,"to":5,"text":"sma","relationship":"association"}] 
;

myDiagram.model = $(go.GraphLinksModel,
{
copiesArrays: true,
copiesArrayObjects: true,
nodeDataArray: nodedata,
linkDataArray: linkdata
});
var myOverview = $(go.Overview, 'myOverviewDiv',{ observed: myDiagram });}
init();
