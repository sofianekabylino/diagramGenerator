package MultiAgentsParticules.core.enums;

public enum DirectionEnum {

	NORTH,NORTH_EAST,EAST,SOUTH_EAST,SOUTH,SOUTH_WEST,WEST,NORTH_WEST,NONE
	
}
