package MultiAgentsParticules.core.enums;

public enum TypeOfAgentEnum {

	BILLE, FISH, SHARK, CHASED, HUNTER, EMPTY, WALL
	
}
