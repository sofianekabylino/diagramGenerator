package MultiAgentsParticules.bille.view;

import java.util.HashMap;
import java.util.Map;

import MultiAgentsParticules.core.Agent;
import javafx.scene.shape.*;

public class MapAgent {

	static Map<Agent, Shape> mapAgent = new HashMap<Agent, Shape>();
}
